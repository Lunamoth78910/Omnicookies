// Keeps the link the same
Game.LoadMod("https://gamrguy.github.io/OmniscientCookies/dist/main.js");